async function loadTools() {
    const container = document.getElementById("tools-grid");

    container.innerHTML = "<p>Loading tools...</p>";

    try {
        const response = await fetch("/api/tools");

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const tools = await response.json();

        renderTools(tools);

    } catch (err) {
        container.innerHTML = `
            <p style="color:red;">
                Failed to load tools.<br>
                ${err}
            </p>
        `;
    }
}

function renderTools(tools) {
    const container = document.getElementById("tools-grid");

    container.innerHTML = "";

    if (!tools.length) {
        container.innerHTML = "<p>No tools found.</p>";
        return;
    }

    for (const tool of tools) {

        const card = document.createElement("div");
        card.className = "tool-card";

        const group =
            tool.group && tool.group.length > 0
                ? tool.group
                : "root";

        const healthy = tool.status === "Healthy";

        card.innerHTML = `
            <h3>${tool.name}</h3>

            <p>
                <strong>Group:</strong>
                ${group}
            </p>

            <p>
                <strong>Status:</strong>
                ${healthy ? "✅ Healthy" : "❌ Broken"}
            </p>

            <p>
                <strong>Source</strong>
            </p>

            <code>${tool.source}</code>

            <br><br>

            <p>
                <strong>Target</strong>
            </p>

            <code>${tool.target}</code>
        `;

        container.appendChild(card);
    }
}

async function refreshTools() {
    await loadTools();
}

const refreshButton = document.getElementById("refresh-tools");

if (refreshButton) {
    refreshButton.addEventListener("click", refreshTools);
}

// Initial load
loadTools();

// Auto refresh every 5 seconds
setInterval(loadTools, 5000);
